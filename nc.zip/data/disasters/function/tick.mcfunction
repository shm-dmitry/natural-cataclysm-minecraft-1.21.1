execute unless entity @e[tag=Catastrofe] at @s run scoreboard players add CatastoTeimpo Tiempo 1
execute if score CatastoTeimpo Tiempo matches 4000 run function disasters:ejecutarrandom
execute if score CatastoTeimpo Tiempo matches 4001 run scoreboard players reset CatastoTeimpo Tiempo

#detector
execute as @e[tag=caos] at @s run return run function disasters:tick/caos


execute as @e[tag=tornado] at @s run function disasters:tick/tornado

#Terremoto
execute as @e at @s unless entity @e[tag=Terremoto] run scoreboard players reset @s Terremoto
function disasters:terremoto/mover
execute as @e[tag=Terremoto] at @s run function disasters:tick/terremoto
execute as @e[tag=generarterremoto] at @s run function disasters:terremoto/terremoto

#Meteoro
#execute as @e[tag=Meteoro] at @s run function disasters:tick/meteor

#Tsunami
execute as @e[tag=Tsunami] at @s run return run function disasters:tick/tsunami

#blackhole
#execute as @e[tag=blackole] at @s run return run function disasters:tick/blackole

#sequia
execute as @e[tag=sequia] at @s run function disasters:sequia/comandos

function disasters:nc/handle_triggers
